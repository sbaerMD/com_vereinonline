<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
class VereinOnlineModelVereinOnline extends JModelItem
{
	/**
	 * @var string message
	 */
	protected $message;
 
	/**
	 * Get the message
         *
	 * @return  string  The message to be displayed to the user
	 */
	public function getMsg()
	{
		if (!isset($this->message))
		{
            $jinput = JFactory::getApplication()->input;
            $vo_id = $jinput->get('vo_id', 1, 'text');
			$this->message = 'VereinOnline.org Kalender-Model f&uumlr "'. $vo_id .'"';
		}
 
		return $this->message;
	}
}